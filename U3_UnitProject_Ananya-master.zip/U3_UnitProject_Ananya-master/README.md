# u3_unitproject_Ananya

Description: In this project, I am using the function leap motion because I find it really interesting how you can code something and at the same time use your body to make something. I will have poeple move their hands in order to make a piece of art. 

<h3>Milestone #1:November 18th, 2016 </h3>
  <strong>Goal:</strong> You should have solid planning done by the end of this milestone.
  <ul>
    <li>I want to make a piece of art using the leap motion function. I want to make the person interact with the leap motion by them moving their hands up and down so that somewhat of a picture is created. My main goal for this point was to have a clear idea of what to use and how leap motion actually works in order to create an effective project. </li> 
     <li>Know what I am doing for the project</li>
       <li>Know what library I am using to create the project</li>
         <li>Understand how to use leap motion</li>
  </ul>
</div>
 
<p>
  <h3>Milestone #2: November 30th, 2016 </h3>
  <strong>Goal:</strong> Finish first prototype 
  <ul>
    <li>By this time I have a working protoype and I will ask people for feedback to see what they enjoyed and what they didn't and then when they give me feedback i will continue working on how to make it more interactive and enjoyable for people to use. </li> 
     <li>Continue making the project better</li>
     <li>Fix anything that doesn't work</li>
     
  </ul>
</p>
 
<div>
  <h3>Milestone #3: December 6th, 2016 (For G block)</br>
  <ul>
    <li>Have the code finished</li>
    <li>Ask people for feedback to see what I should improve</li>
    <li>if not finished then do the final touches to the code</li>
    <li>make sure that all of the gestures work well so that the painting can be created</li>
  </ul>
</div>
 
<div>
  <h3><strong>Presentation:</strong> December 8th, 2016 (For G block)</br>
</div>
